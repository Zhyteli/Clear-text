package com.company;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Lab {
    public static void main(String[] args) {
        MyWindow myWindow = new MyWindow();
    }
}
class MyWindow extends JFrame {
    MyWindow() {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        MyPanel myPanel = new MyPanel();
        this.getContentPane().add(myPanel);
        this.setSize(400,400);
    }
}
class MyPanel extends JPanel{
    MyPanel(){
        JTextField field = new JTextField(20);
        JTextArea area = new JTextArea(1,20);
        JButton button1 = new JButton("Очистить");
        JButton button2 = new JButton("Выход");
        JRadioButton radioButton1 = new JRadioButton("Заменить существительное местоимением");
        JRadioButton radioButton2 = new JRadioButton("Вставить после глагола «бы»");
        JRadioButton radioButton3 = new JRadioButton("Заменить наречие другим, выбранным из списка");
        ButtonGroup buttonGroup = new ButtonGroup();
        String[] items = {"никогда", "нигде", "здесь", "там", "тут"};
        JComboBox comboBox = new JComboBox(items);

        buttonGroup.add(radioButton1);
        buttonGroup.add(radioButton2);
        buttonGroup.add(radioButton3);
        this.add(field);
        this.add(area);
        this.add(button1);
        this.add(button2);
        this.add(radioButton1);
        this.add(radioButton2);
        this.add(radioButton3);
        this.add(comboBox);
        radioButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                String text = field.getText();
                String[] words = text.split(" ");
                if (words.length >= 2 && !words[2].equals("бы"))
                {
                    words[1] += " бы";
                    text = String.join(" ", words);
                    area.setText(text);
                }
            }
        });
        radioButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String text = field.getText();
                if(text != "") {
                    String[] mest = text.split(" ");
                    if (mest.length >= 1){
                        char Element = mest[0].charAt(mest[0].length() - 1);
                        if (Element == 'е' || Element == 'о'){
                            mest[0] = "Оно";
                        }
                        else if (Element == 'ы'|| Element == 'и'){
                            mest[0] = "Они";
                        }
                        else {mest[0] = "Он/Она"; }
                        text = String.join(" ",mest);
                        area.setText(text);
                    }
                }
            }
        });
        radioButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = field.getText();
                if(text != ""){
                    String[] words = text.split(" ");
                    if (words.length >= 3) {
                        if (!words[2].equals("бы")) {
                            words[2] = (String) comboBox.getSelectedItem();
                            text = String.join(" ", words);
                        }
                    }
                    else {
                        words[3] = (String) comboBox.getSelectedItem();
                        text = String.join(" ", words);
                    }
                    area.setText(text);
                }
            }
        });
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                field.setText("");
                area.setText("");
            }
        });
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }
}

