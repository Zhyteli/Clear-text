package Лаба821;
import java.awt.*;
import java.awt.event.*;
public class MouseDraw extends Canvas {
    private int lastX, lastY;
    private int ex, ey;
    static private boolean clear=false;
    static Button buttonclear=new Button("clear");
    public MouseDraw () {
        super();
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                lastX = e.getX();
                lastY = e.getY();
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                ex=e.getX();
                ey=e.getY();
                repaint();
            }
        });

        addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (e.getKeyChar()==' ') {
                    clear = true;
                    repaint();
                }
            }
        });
        buttonclear.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                if (e.getSource()==buttonclear)	{
                    clear=true;
                    repaint();
                }
            }

        });
    }

    public void update(Graphics g) {
        if (clear) {
            g.clearRect(0, 0, getWidth(), getHeight());
            clear = false;
        } else {
            g.drawLine(lastX, lastY, ex, ey);
            lastX=ex;
            lastY=ey;
        }
    }
    public static void main(String s[]) {
        final Frame f = new Frame("Draw");
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                f.dispose();
            }
        });
        f.setBounds(100,100, 500, 500);

        final Canvas c = new MouseDraw();
        buttonclear.setBounds(20,20,50,40);
        f.add(buttonclear);
        f.add(c);
        f.setVisible(true);


    }
}
