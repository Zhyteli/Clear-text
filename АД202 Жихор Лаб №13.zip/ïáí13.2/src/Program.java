import java.util.Scanner;

@FunctionalInterface
interface GenericInterface<T> {
    T func(T t, T r);
}
public class Program {
    public static void main( String[] args ) {

        GenericInterface<String> program = (w, s) -> {
            int repeat = 0;
            char[] wordArr = w.toCharArray();
            for (int i = 0; i < wordArr.length - 1; i++) {
                for (int j = i + 1; j < wordArr.length; j++) {
                    if (wordArr[i] == wordArr[j]) {
                        repeat++;
                    }
                }
            }
            if(repeat > 0) {
                String temp = w;
                w = s + temp;
            }
            else
                w += s;
            return w;
        };

        String word, symbol;
        System.out.println("Введите слово и символ");
        Scanner sc = new Scanner(System.in);
        word = sc.nextLine();
        symbol = sc.nextLine();
        System.out.println("Результат работы:" + program.func(word, symbol));
    }
}