import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        MyInterface ref;
        Scanner scanner = new Scanner(System.in);
        String testString = scanner.nextLine();
        ref =() -> testString.replaceAll("[,]","");
        System.out.println(ref.reverse());
    }
}
