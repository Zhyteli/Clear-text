public interface MyInterface {
    String reverse();
}
