package com.company;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        List<String> strList = new ArrayList<String>();
        String testString = "Привет, мир!Я был создан, для великой цели - изучения.Спасибо Американским веб-сайтам за консультирование.";
        String[] sentences = testString.split("[\\.\\!\\?]");
        for (int f = 0; f < sentences.length; f++){
            strList.add(sentences[f]);
        }
        Collections.sort(strList);
        for (String s : strList){
            System.out.println(s);
        }
    }
}
