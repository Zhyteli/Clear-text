package com.company;
public class Cart {

    private Item[] stack; // массив для реализации стека
    protected int capacity; // указатель на вершину стека

    public Cart(int capacity) {
        this.capacity = capacity;
        if (capacity > 0){
            stack = new Item[capacity];
        }
        else {
            System.out.println("Ваше число неверно, измените");
        }
    }
    public void AddItemOnCart(Item[] item){
        for (int i = 0; i < stack.length; i++){
            this.stack[i] = item[i];
        }
    }
    public float SumItem (){
        float sum = 0;
        for (int i = 0; i < stack.length; i++){
            sum += this.stack[i].price;
        }
        return sum;
    }
    public void raiseItemPrices(int percent){
        System.out.println("Цена поднялась на " + percent + "%");
        for (int i = 0; i < stack.length; i++){
            stack[i].price += (stack[i].price * percent / 100);
            System.out.println(stack[i].name + " " + stack[i].price);
        }
    }
    public void cutItemPrices(int percent){
        System.out.println("Цена понизисась на " + percent + "%");
        for (int i = 0; i < stack.length; i++){
            stack[i].price -= (stack[i].price * percent / 100);
            System.out.println(stack[i].name + " " + stack[i].price);
        }
    }
    public double calculateItemPrices() {
        double comPrice=0;
        for(int i = 0; i< stack.length; i++) {
            comPrice += stack[i].price;
        }
        return comPrice;
    }
}
