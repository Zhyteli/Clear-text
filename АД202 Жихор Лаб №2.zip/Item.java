package com.company;

public class Item {
    String name;
    float price;

    public Item (String name, float price)
    {
        this.name = name;
        this.price = price;
    }
    public float raiseItemPrices(float price,float percent) {
        if (percent < 0){
            price = 0;
            return price;
        }
       float newPrice=price+price*percent/100;
        return newPrice;
    }
    public float cutItemPrices(float price,float percent) {
        float newPrice = 0;
        if (percent < 0){
            return newPrice;
        }
        newPrice=price-price*percent/100;
        if (newPrice < 0){
            newPrice = 0;
        }
        return newPrice;
    }
}

