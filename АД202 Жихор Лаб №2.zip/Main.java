package com.company;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Вместимость вашей корзины");
        Scanner scanner1 = new Scanner(System.in);
        int capacity = scanner1.nextInt();
        Cart cart = new Cart(capacity);
        Item[] item = new Item[cart.capacity];
        System.out.println("Введите данные: ");
        for (int i = 0; i < item.length; i++){
            Scanner scanner = new Scanner(System.in);
            System.out.println("Название товара: ");
            String name = scanner.nextLine();
            System.out.println("Цена: ");
            float price = scanner.nextFloat();
            item[i] = new Item(name,price);
        }
        System.out.println("Сумма цен товаров в корзине: ");
        cart.AddItemOnCart(item);
        System.out.println(cart.SumItem());
        cart.raiseItemPrices(20);
        cart.cutItemPrices(15);
    }
}
