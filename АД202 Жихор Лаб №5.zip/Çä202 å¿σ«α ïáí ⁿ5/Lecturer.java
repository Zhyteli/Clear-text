package com;

public class Lecturer extends Person {
    String Department;
    String Salary;
    public Lecturer(String Surname, String Name, String Age, String Department, String Salary){
        super(Surname,Name,Age);
        this.Department = Department;
        this.Salary = Salary;
    }
    public String getDepartment(){
            return Department;
        }
        public void setDepartment(String Department) {
        this.Department = Department;
    }
        public String getSalary(){
        return Salary;
        }
        public void setSalary(String Salary) {
        this.Salary = Salary;
    }
    public void printInfo(){
        System.out.println("Преподаватель кафедры" + Department + " " + Surname + " " + Name +
                ", возрвст: " + Age + ". Зарплата:" + Salary);
    }
}
