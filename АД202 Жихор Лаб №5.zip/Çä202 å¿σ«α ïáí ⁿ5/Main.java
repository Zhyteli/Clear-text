package com;

import java.util.Scanner;

public class Main {
    public static void main(String[] args){

        Person[] person = new Person[1];
        Person[] student = new Student[1];
        Person[] lecturer = new Lecturer[1];
        System.out.println("Введите данные Студента: ");
        for (int i = 0; i < student.length; i++) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Введите фамилию: ");
            String Surname = scanner.nextLine();
            System.out.println("Введите имя:");
            String Name = scanner.nextLine();
            System.out.println("Введите группу:");
            String Group = scanner.nextLine();
            System.out.println("Введите возрвст:");
            String Age = scanner.nextLine();
            System.out.println("Введите номер студенческого билета:");
            String StudID = scanner.nextLine();
            student[i] = new Student(Surname,Name,Group,Age,StudID);

        }
        System.out.println("Введите данные лектора: ");
        for (int i = 0; i < lecturer.length; i++) {
            Scanner scanner1 = new Scanner(System.in);
            System.out.println("Введите кафедру: ");
            String Department = scanner1.nextLine();
            System.out.println("Введите фамилию лектора: ");
            String Surname = scanner1.nextLine();
            System.out.println("Введите имя лектора: ");
            String Name = scanner1.nextLine();
            System.out.println("Введите возрвст лектора:");
            String Age = scanner1.nextLine();
            System.out.println("Введите зарплату:");
            String Salary = scanner1.nextLine();
            lecturer[i] = new Lecturer(Department,Surname,Name,Age,Salary);
            }
        System.out.println("Введите данные: ");
        for (int i = 0; i < person.length; i++) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Введите фамилию: ");
            String Surname = scanner.nextLine();
            System.out.println("Введите имя:");
            String Name = scanner.nextLine();
            System.out.println("Введите возрвст:");
            String Age = scanner.nextLine();
            person[i] = new Person(Surname, Name, Age);
        }
        for (int i = 0; i < student.length; i++) {student[i].printInfo();}
        for (int i = 0; i < lecturer.length; i++) {lecturer[i].printInfo();}
        for (int i = 0; i < person.length; i++) {person[i].printInfo();}

    }
}
