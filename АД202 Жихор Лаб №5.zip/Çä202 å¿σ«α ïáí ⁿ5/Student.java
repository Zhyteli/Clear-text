package com;
import java.util.Scanner;
public class Student extends Person {
    String Group;
    String StudID;
    public Student(String Surname, String Name, String Age, String Group, String StudID){
        super(Surname,Name,Age);
        this.Group = Group;
        this.StudID = StudID;
    }
    public String getGroup(){
        return Group;
    }
    public void setGroup(String Group) {
        this.Group = Group;
    }
    public String getStudID(){
        return StudID;
    }
    public void setStudID(String StudID) {
        this.StudID = StudID;
    }
    public void printInfo(){
        System.out.println("Студент группы " + Group + " " + Surname + " " + Name +
                ", возрвст:" + Age + ". Номер суденческого билета:" + StudID);
    }
}
