package com;

public class Person {
    String Surname;
    String Name;
    String Age;
    public Person(String Surname, String Name, String Age){
        this.Surname = Surname;
        this.Name = Name;
        this.Age = Age;
    }
    public String getSurname(){
        return Surname;
    }
    public void setSurname(String Surname){
        this.Surname = Surname;
    }
    public String getName(){
        return Name;
    }
    public void setName(String Name) {
        this.Name = Name;
    }
    public String getAge(){
        return Age;
    }
    public void setAge(String Age){
        this.Age = Age;
    }
    public void printInfo(){
        System.out.println("Человек" + " " + Surname + " " + Name + ", возрвст:" + Age);
    }
}
