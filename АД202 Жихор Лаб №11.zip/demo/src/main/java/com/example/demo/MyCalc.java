package com.example.demo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class MyCalc extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {

        VBox root = new VBox();
        root.setStyle("-fx-background-color: #EDF0F2");

        Scene scene = new Scene(root);

        // Добавляем меню
        root.getChildren().add(configureMenu());

        // Получаем HBox с текстовым полем внутри
        HBox box = configureResultView();
        // Добавляем HBox в root-вершину
        root.getChildren().add(box);
        // Устанавливаем отступы для HBox
        VBox.setMargin(box, new Insets(10, 10, 2, 10));

        root.getChildren().add(configureButtons());
        primaryStage.setTitle("My calc");
        primaryStage.setResizable(true);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private class MyButton extends Button {
        MyButton(String text) {
            super(text);
            this.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        }
    }
    private class MyRadioButton extends RadioButton {
        MyRadioButton(String text){
            super(text);
            this.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        }
    }

    private GridPane configureButtons() {
        GridPane pane = new GridPane();
        pane.add(new MyRadioButton("Градусы"), 0,0);
        pane.add(new MyRadioButton("Радианы"), 1,0);
        pane.add(new MyRadioButton("Грады"), 2,0);
        // 1ый ряд
        pane.add(new MyButton("MC"), 3, 0);
        pane.add(new MyButton("MR"), 4, 0);
        pane.add(new MyButton("MS"), 5, 0);
        pane.add(new MyButton("M+"), 6, 0);
        pane.add(new MyButton("M-"), 7, 0);

        // 2ой ряд
        pane.add(new MyButton(""), 0, 2);
        pane.add(new MyButton("Inv"), 1, 2);
        pane.add(new MyButton("In"), 2, 2);
        pane.add(new MyButton("("), 3, 2);
        pane.add(new MyButton(")"), 4, 2);
        pane.add(new MyButton("<-"), 5, 2);
        pane.add(new MyButton("CE"), 6, 2);
        pane.add(new MyButton("C"), 7, 2);
        pane.add(new MyButton("±"), 8, 2);
        pane.add(new MyButton("√"), 9, 2);

        // 3ий ряд
        pane.add(new MyButton("Int"),0,3);
        pane.add(new MyButton("sinh"),1,3);
        pane.add(new MyButton("sin"),2,3);
        pane.add(new MyButton("x^y"),3,3);
        pane.add(new MyButton("x^1/y"),4,3);
        pane.add(new MyButton("7"), 5, 3);
        pane.add(new MyButton("8"), 6, 3);
        pane.add(new MyButton("9"), 7, 3);
        pane.add(new MyButton("/"), 8, 3);
        pane.add(new MyButton("%"), 9, 3);

        // 4ый ряд
        pane.add(new MyButton("dms"),0,4);
        pane.add(new MyButton("cosh"),1,4);
        pane.add(new MyButton("cos"),2,4);
        pane.add(new MyButton("x^y"),3,4);
        pane.add(new MyButton("x^1/y"),4,4);
        pane.add(new MyButton("4"), 5, 4);
        pane.add(new MyButton("5"), 6, 4);
        pane.add(new MyButton("6"), 7, 4);
        pane.add(new MyButton("*"), 8, 4);
        pane.add(new MyButton("1/х"), 9 , 4);


        // 5ый ряд
        pane.add(new MyButton("pi"),0,5);
        pane.add(new MyButton("tanh"),1,5);
        pane.add(new MyButton("tan"),2,5);
        pane.add(new MyButton("x^3"),3,5);
        pane.add(new MyButton("x^1/3"),4,5);
        pane.add(new MyButton("1"), 5, 5);
        pane.add(new MyButton("2"), 6, 5);
        pane.add(new MyButton("3"), 7, 5);
        pane.add(new MyButton("-"), 8, 5);
        pane.add(new MyButton("="), 9, 5, 1, 3);

        // 6ой ряд
        pane.add(new MyButton("F-E"),0,6);
        pane.add(new MyButton("Exp"),1,6);
        pane.add(new MyButton("Mod"),2,6);
        pane.add(new MyButton("log"),3,6);
        pane.add(new MyButton("10^x"),4,6);
        pane.add(new MyButton("0"), 5, 6, 2, 1);
        pane.add(new MyButton(","), 7, 6);
        pane.add(new MyButton("+"), 8, 6);

        // Свойства колонок
        ColumnConstraints cc = new ColumnConstraints();
        cc.setFillWidth(true);
        cc.setHgrow(Priority.ALWAYS);
        pane.getColumnConstraints().addAll(cc,cc,cc,cc,cc,cc,cc,cc,cc);

        pane.setStyle("-fx-padding: 2 10 4 10");
        pane.setHgap(6);
        pane.setVgap(6);
        return pane;
    }

    private HBox configureResultView() {

        // Создаем менеджер HBox, куда
        // мы поместим текстовое поле
        HBox box = new HBox();

        // Устанавливаем нужный стиль для менеджера
        box.setStyle("-fx-border-style: solid inside;" +
                "-fx-border-width: 1;" +
                "-fx-border-radius: 3;" +
                "-fx-border-color: gray;" +
                "-fx-padding: 25 2 6 30;" +
                "-fx-background-color: linear-gradient(to bottom," +
                " #d3eefb 0%,#f4f8f9 59%);");

        // Создаем текстовое поле
        Text text = new Text("0");
        text.setTextAlignment(TextAlignment.RIGHT);
        text.setFont(new Font(40));

        // Добавяем текстовое поле в менеджер HBox
        // устанавливаем выравнивание
        box.getChildren().add(text);
        box.setAlignment(Pos.BOTTOM_RIGHT);

        return box;
    }

    private MenuBar configureMenu() {
        MenuBar bar = new MenuBar();

        Menu view = new Menu("_Вид");
        Menu edit = new Menu("_Правка");
        Menu help = new Menu("_Справка");

        bar.getMenus().addAll(view, edit, help);

        return bar;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
