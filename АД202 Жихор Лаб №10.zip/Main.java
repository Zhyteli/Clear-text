package com.company;

public class Main {

    public static void main(String[] args) {
        Generic<Donner> donnerGeneric = new Generic<>();
        donnerGeneric.addToEnd(new Donner(1235, 548, 55));
        donnerGeneric.addToEnd(new Donner(12, 5, 6));
        donnerGeneric.addToEnd(new Donner(1235, 548, 55));

        for (Donner generic: donnerGeneric){
            System.out.println(generic);
        }
    }
}
