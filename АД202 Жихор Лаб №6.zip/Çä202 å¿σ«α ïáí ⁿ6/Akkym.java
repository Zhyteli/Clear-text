package com.company;

public interface Akkym {
    int fold(int[] arr);
}
