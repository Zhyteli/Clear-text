package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        System.out.println("Размер массива:");
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        System.out.println("Элементы массива:");
        int[] arr = new int[n];
        for (int i = 0; i < n; i++){
            arr[i] = scanner.nextInt();
        }
        Slozh slozh = new Slozh();
        Prost prost = new Prost();
        slozh.fold(arr);
        prost.fold(arr);
    }
}
