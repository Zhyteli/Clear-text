package com.company;

public class Slozh implements Akkym{
    int neprostoe;
    @Override
    public int fold(int[] arr) {
        neprostoe = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 2; j <= arr[i]/2; j++){
                if (arr[i]%j == 0){
                    neprostoe++;
                    break;
                }
            }
        }
        System.out.print("Не простые числа: ");
        System.out.println(neprostoe);
        return neprostoe;
    }
}
