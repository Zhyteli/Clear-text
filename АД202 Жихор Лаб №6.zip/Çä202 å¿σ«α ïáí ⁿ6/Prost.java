package com.company;

public class Prost implements Akkym{
    int prostoe, a;

    @Override
    public int fold(int[] arr) {
        prostoe = arr.length;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 2; j <= arr[i]/2; j++){
                if (arr[i]%j == 0 && arr[i] != j){
                    prostoe--;
                    break;
                }
            }
        }
        System.out.print("Простые числа: ");
        System.out.println(prostoe);
        return prostoe;
    }
}

