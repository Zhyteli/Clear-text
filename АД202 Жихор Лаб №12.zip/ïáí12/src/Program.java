import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Program extends Thread {
    private File file;
    private String str;
    private static int totalNum = 0;
    private int currentNum;
    public Program (File file, String str, String pathFile){
        this.file = file;
        this.str = str;
        currentNum = totalNum++;
    }
    private void pause(double seconds){ //создаем паузу
        try {
            Thread.sleep (Math.round(1000.0*seconds ));
        }
        catch(InterruptedException ie) {}
    }
    public void run(){
        boolean found = false;
        try{
            BufferedReader br = new BufferedReader(new FileReader(file.getPath()));
            try{
                String line;
                while ((line = br.readLine()) != null)
                {
                    if (line.contains(str))
                        found = true;
                    //выводим номер потока и результат
                    System.out.println("Stream " + currentNum + ":" + found);
                    pause(Math.random());
                }
            } finally {
                br.close();
            }
        } catch(IOException ioe)
        {
            System.out.println("Error while opening the file!");
        }
    }



    public static void main(String[] args) {
        Path path = Paths.get("\"C:\\Users\\Asus\\Desktop\\ЕЕЕ.txt\"");
        // создадим новый файл
        File newFile = new File(String.valueOf(path));
        try {
            boolean created = newFile.createNewFile();
            if (created)
                System.out.println("File has been created");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        try {
            String stringToWrite = "Behind the word mountains.\nFar from the countries Vokalia and Consonantia.\nFar far away.";
            byte[] bs = stringToWrite.getBytes();
            Path writtenFilePath = Files.write(path, bs);
            System.out.println("Written content in file:\n"+ new String(Files.readAllBytes(writtenFilePath)));
        } catch (Exception e) {
            e.printStackTrace();
        }

        Program findString = new Program(newFile, "Far far away.", path.toString());
        findString.start();
    }
}

